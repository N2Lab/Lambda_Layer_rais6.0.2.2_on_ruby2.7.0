# frozen_string_literal: true

class Tracer
  VERSION = "0.1.0"
end
